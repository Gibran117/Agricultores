package Experimento_con_Manzanas;

/**
 *
 * @author mi
 */
public class TestManzana {

    public static void main(String[] args) {
        VistaManzana vistaManzana = new VistaManzana();
        vistaManzana.run();
    }

}
