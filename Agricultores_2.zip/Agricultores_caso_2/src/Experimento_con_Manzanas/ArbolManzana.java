package Experimento_con_Manzanas;

/**
 *
 * @author mi
 */
public class ArbolManzana extends Arbol {

    public ArbolManzana(
            Integer numero,
            Integer numeroFrutas,
            Integer alturaCm,
            Integer pesoPromedioFruta) {

        super(numero, numeroFrutas, alturaCm, pesoPromedioFruta);
    }

}
