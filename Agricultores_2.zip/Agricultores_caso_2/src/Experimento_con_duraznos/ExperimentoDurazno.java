package Experimento_con_duraznos;

/**
 *
 * @author mi
 */
public class ExperimentoDurazno {
    
    private ArbolDurazno[] duraznos;

    public int getPromedioNumeroDuraznos() {
        int suma = 0;
        for (int i = 0; i < 5; i++) {
            suma = suma + duraznos[i].getNumeroFrutas();
        }
        return suma / 5;
    }

    public int getPromedioAlturaArbolDurazno() {
        int suma = 0;
        for (int i = 0; i < 5; i++) {
            suma = suma + duraznos[i].getAlturaCm();
        }
        return suma / 5;
    }

    public int getPromedioPesoDurazno() {
        int suma = 0;
        for (int i = 0; i < 5; i++) {
            suma = suma + duraznos[i].getPesoPromedioFruta();
        }
        return suma / 5;
    }

    public void setDuraznos(ArbolDurazno[] duraznos) {
        this.duraznos = duraznos;
    }
    
}
