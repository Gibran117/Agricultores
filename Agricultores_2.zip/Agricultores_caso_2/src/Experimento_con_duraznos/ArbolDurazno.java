package Experimento_con_duraznos;

import Experimento_con_Manzanas.Arbol;

/**
 *
 * @author mi
 */
public class ArbolDurazno extends Arbol {

    public ArbolDurazno(
            Integer numero,
            Integer numeroFrutas,
            Integer alturaCm,
            Integer pesoPromedioFruta) {

        super(numero, numeroFrutas, alturaCm, pesoPromedioFruta);
    }

}
