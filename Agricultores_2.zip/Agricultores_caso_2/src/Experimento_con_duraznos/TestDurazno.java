package Experimento_con_duraznos;

/**
 *
 * @author mi
 */
public class TestDurazno {
    
    public static void main(String[] args) {
        VistaDurazno vistaDurazno = new VistaDurazno();
        vistaDurazno.run();
    }
}
