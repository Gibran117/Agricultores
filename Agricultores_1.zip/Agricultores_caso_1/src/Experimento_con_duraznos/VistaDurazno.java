package Experimento_con_duraznos;

/**
 *
 * @author mi
 */
public class VistaDurazno {

    public void run() {

        ArbolDurazno[] duraznos = new ArbolDurazno[5];
        duraznos[0] = new ArbolDurazno(1, 15, 180, 200);
        duraznos[1] = new ArbolDurazno(2, 16, 190, 160);
        duraznos[2] = new ArbolDurazno(3, 17, 200, 200);
        duraznos[3] = new ArbolDurazno(4, 16, 230, 189);
        duraznos[4] = new ArbolDurazno(5, 16, 180, 168);

        ExperimentoDurazno exp = new ExperimentoDurazno();
        exp.setDuraznos(duraznos);

        System.out.println("Rendimiento del cultivo de duraznos");
        int promedioDuraznos = exp.getPromedioNumeroDuraznos();
        System.out.println("Numero promedio de duraznos " + promedioDuraznos);
        int promedioAlturaArbolDurazno = exp.getPromedioAlturaArbolDurazno();
        System.out.println("Altura promedio de los Arboles " + promedioAlturaArbolDurazno);
        int PromedioPesoDurazno = exp.getPromedioPesoDurazno();
        System.out.println("Peso promedio de los duraznos " + PromedioPesoDurazno);

    }

}
