package Experimentos_con_Manzanas;

import Experimentos_con_Duraznos.Vista;

/**
 *
 * @author mi
 */
public class TestManzana {

    public static void main(String[] args) {
        TestManzana test = new TestManzana();
        test.test();
    }

    public void test() {
        ArbolManzana[] manzanos = new ArbolManzana[5];
        manzanos[0] = new ArbolManzana(1, 16, 230, 200);
        manzanos[1] = new ArbolManzana(2, 20, 200, 190);
        manzanos[2] = new ArbolManzana(3, 13, 210, 180);
        manzanos[3] = new ArbolManzana(4, 25, 190, 200);
        manzanos[4] = new ArbolManzana(5, 22, 198, 205);

        ExperimentoManzana experimentoManzana = new ExperimentoManzana();

        Vista vista = new Vista();
        vista.setArboles(manzanos);
        vista.setExperimento(experimentoManzana);
        vista.run();
    }

}
