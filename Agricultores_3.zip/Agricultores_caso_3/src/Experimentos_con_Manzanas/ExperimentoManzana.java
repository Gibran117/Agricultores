package Experimentos_con_Manzanas;

import Experimentos_con_Duraznos.Arbol;
import Experimentos_con_Duraznos.Experimento;

/**
 *
 * @author mi
 */
public class ExperimentoManzana implements Experimento {
    
    private ArbolManzana[] manzanos;
    private String especie = "Manzanas";
    
    public int getPromedioNumeroFrutas() {
        int suma = 0;
        for (int i = 0; i < 5; i++) {
            suma = suma + manzanos[i].getNumeroFrutas();
        }
        return suma / 5;
    }

    public int getPromedioAlturaArbol() {
        int suma = 0;
        for (int i = 0; i < 5; i++) {
            suma = suma + manzanos[i].getAlturaCm();
        }
        return suma / 5;
    }

    public int getPromedioPesoFruta() {
        int suma = 0;
        for (int i = 0; i < 5; i++) {
            suma = suma + manzanos[i].getPesoPromedioFruta();
        }
        return suma / 5;
    }

    public void setArboles(Arbol[] arboles) {
        this.manzanos = (ArbolManzana[]) arboles;
    }
    
    public String getEspecie() {
        
        return especie;
        
    }

    @Override
    public int getPromedioAltuaraArbol() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
