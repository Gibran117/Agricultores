package Experimentos_con_Manzanas;

import Experimentos_con_Duraznos.Arbol;

/**
 *
 * @author mi
 */
public class ArbolManzana extends Arbol {

    public ArbolManzana(
            Integer numero,
            Integer numeroFrutas,
            Integer alturaCm,
            Integer pesoPromedioFruta) {

        super(numero, numeroFrutas, alturaCm, pesoPromedioFruta);
    }

}
