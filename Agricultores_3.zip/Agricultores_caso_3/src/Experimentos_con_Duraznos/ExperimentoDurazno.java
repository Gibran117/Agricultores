package Experimentos_con_Duraznos;

/**
 *
 * @author mi
 */
public class ExperimentoDurazno implements Experimento {

    private ArbolDurazno[] duraznos;
    private String especie = "Duraznos";

    public int getPromedioNumeroFrutas() {
        int suma = 0;
        for (int i = 0; i < 5; i++) {
            suma = suma + duraznos[i].getNumeroFrutas();
        }
        return suma / 5;
    }

    public int getPromedioAlturaArbol() {
        int suma = 0;
        for (int i = 0; i < 5; i++) {
            suma = suma + duraznos[i].getAlturaCm();
        }
        return suma / 5;
    }

    public int getPromedioPesoFruta() {
        int suma = 0;
        for (int i = 0; i < 5; i++) {
            suma = suma + duraznos[i].getPesoPromedioFruta();
        }
        return suma / 5;
    }

    public void setArboles(Arbol[] arboles) {
        this.duraznos = (ArbolDurazno[]) arboles;
    }

    public String getEspecie() {

        return especie;

    }

    @Override
    public int getPromedioAltuaraArbol() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
