package Experimentos_con_Duraznos;

/**
 *
 * @author mi
 */
public interface Experimento {

    public int getPromedioNumeroFrutas();

    public int getPromedioAltuaraArbol();

    public int getPromedioPesoFruta();

    public void setArboles(Arbol[] arboles);

    public String getEspecie();

}
