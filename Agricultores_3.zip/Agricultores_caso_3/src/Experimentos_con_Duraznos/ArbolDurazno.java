package Experimentos_con_Duraznos;

/**
 *
 * @author mi
 */
public class ArbolDurazno extends Arbol {
    
     public ArbolDurazno(
            Integer numero,
            Integer numeroFrutas,
            Integer alturaCm,
            Integer pesoPromedioFruta) {

        super(numero, numeroFrutas, alturaCm, pesoPromedioFruta);
    }

}
